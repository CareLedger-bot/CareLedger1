# CareLedger — test results

**Test method:** Python standard-library `unittest` + local HTTP requests.

**Command:**

```bash
python -m unittest discover -s tests -v
```

**Outcome:** **12 tests passed, 0 failures, 0 errors**.

| Test group | Checks |
| --- | --- |
| Persistence | Creates and updates records; searches the local database |
| Audit | Captures created/updated events, modified field names and actor ID |
| Roles | A viewer cannot create or edit records |
| Validation | Rejects invalid dates, empty fields and unsupported status values |
| Error handling | Allows requests with no changes without adding false audit events |
| Security concepts | Password hashes, SQL parameterisation, output escaping, CSRF tokens and cross-origin checks |
| HTTP interface | Sign-in, login failures and filtered search pages |

Six screenshots were generated from actual HTML responses by running the application against temporary fictional data. These illustrate the interface; they are **not substitutes for tests**.

## Known limitations

- Demo accounts deliberately share a published password.
- The prototype stores the SQLite database unencrypted.
- Security and functionality testing is limited to the situations covered above and is not a security audit.
- This is a learning project, not an approved medical-record application.
