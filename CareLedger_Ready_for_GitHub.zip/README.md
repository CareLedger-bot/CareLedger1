# CareLedger — a fictional healthcare-record prototype

**A Python + SQLite portfolio project exploring records, access permissions and accountability.**

CareLedger is a locally run, educational web application built to explore a practical software-design question:

> How can a healthcare information system make records easy for authorised people to find and update while recording changes and limiting inappropriate access?

The application is a **prototype, not a real electronic health-record system**. All example patients are imaginary, and no real personal or medical information should be entered.

![Patient overview screenshot](screenshots/02-patient-overview.png)

## What you can do

| Capability | Demonstration |
| --- | --- |
| Add fictional records | A form validates names, dates, record status and notes before saving. |
| Search records | Search by patient name or a generated demonstration ID. |
| View and edit records | Clinicians and administrators can update entries. |
| Compare user permissions | A viewer has read-only access and cannot add or edit records. |
| View change history | Creates and edits are logged with an account, time and fields changed. |
| Handle errors | Invalid forms, non-existent records and unauthorised actions receive clear errors. |
| Store data locally | SQLite keeps records between runs on the same computer. |

The prototype includes a **login screen, patient dashboard, record-entry form, individual patient page and audit-trail page**.

## See the demonstration

| Sign in | Patient directory |
| --- | --- |
| ![Sign in](screenshots/01-sign-in.png) | ![Directory](screenshots/02-patient-overview.png) |

| New record | Edit + change history |
| --- | --- |
| ![New record](screenshots/03-create-patient.png) | ![Change history](screenshots/05-record-and-change-history.png) |

[See the separate audit-trail screenshot](screenshots/06-audit-trail.png).

## Run it locally

You need **Python 3.11 or newer**. Running the application requires **no extra Python packages**.

1. Download this repository as a ZIP, or clone it.
2. Open a terminal in the `CareLedger` folder.
3. Start the app:

   ```bash
   python app.py
   ```

4. Visit **http://127.0.0.1:8765/login** in a web browser.
5. Choose a demonstration role and sign in using the password below.

**Demonstration accounts**

| Username | Password | Permission |
| --- | --- | --- |
| `admin` | `DemoPass!2026` | View, add, edit, review audit history |
| `clinician` | `DemoPass!2026` | View, add, edit, review audit history |
| `viewer` | `DemoPass!2026` | View records only |

**These are deliberately shared demo credentials.** They are unsuitable for use beyond this local learning prototype. The application starts with five entirely fictional records.

To use a different port:

```bash
python app.py --port 8888
```

A local `careledger-demo.sqlite3` database is created on first launch. It is listed in `.gitignore` to avoid including locally entered data in GitHub uploads. Deleting it resets the sample data the next time the app launches.

## Testing

Run the full built-in test suite from the repository folder:

```bash
python -m unittest discover -s tests -v
```

The suite currently contains **12 automated tests** covering:

- database setup and sample records;
- create, search, update and change history;
- validation of invalid dates and missing or oversized inputs;
- enforcing viewer read-only permissions;
- password hashing and incorrect sign-ins;
- rejection of invalid CSRF tokens and cross-origin submissions;
- escaping untrusted HTML and parameterising SQL queries.

**Verified:** 12/12 tests passing in the supplied development environment (see [`TEST_RESULTS.md`](TEST_RESULTS.md)).

The included images are screenshots rendered from the application's own HTML responses. To recapture them using Playwright (an optional documentation-only dependency), install Playwright and Chromium first, then run `python capture_screenshots.py`.

## Technical design

```text
Browser (HTML forms)
    |
    v
Python standard-library HTTP server  <--- session cookies + CSRF checking
    |
    +-- Role permissions: admin / clinician / viewer
    |
    +-- Input validation + HTML escaping
    |
    +-- Add / search / edit record operations
    |
    v
SQLite: users, patients, audit
```

The app uses `http.server` rather than a web framework to make request handling, input validation and database operations visible in a relatively small codebase. SQLite records are stored in three tables. Patient IDs in the interface are formatted as `PT-1001` etc. Audit rows capture **who** made a change, **when**, and **which fields** changed, without duplicating the contents of clinical notes.

Password checks use salted PBKDF2-HMAC-SHA256, SQL queries use parameters, and edit routes perform server-side role checks. These are demonstrations of security ideas; they do **not** make the app suitable for handling real healthcare data.

## Security limitations — important

CareLedger is **not production-ready**, NHS-approved, compliant with healthcare regulations or safe for real patient information. In particular:

- it deliberately uses publicly documented shared demo credentials;
- SQLite data is **not encrypted at rest**;
- it serves HTTP on **localhost only**, not a production HTTPS deployment;
- it does not implement account registration, password reset, MFA, professional identity checks, backup/recovery or comprehensive audit retention;
- the access controls are an educational simplification, not a clinically appropriate authorisation model.

**Never enter real patient data. Do not expose the demo server to the internet.**

## Ideas to extend the project

1. Add a record-change comparison view and test how to preserve audit history safely.
2. Introduce tests for conflicting updates from two users.
3. Separate the database and HTTP layers into modules to improve maintainability.
4. Explore encryption, least-privilege access, encrypted backups, and the limits of audit logging.
5. Conduct basic usability testing with fictional tasks to see whether records are easy to find.

## Portfolio reflection prompts

If you use this project in an application or interview, be able to explain:

- Why does a **viewer** have read-only access?
- Why are **audit logs** useful, and why don't they make a system automatically secure?
- Why use **parameterised SQL** instead of inserting typed input into query strings?
- What happens when a user tries an **invalid date** or edits a missing record?
- What would have to change before this could ever be used with **real healthcare data**?

**Authorship and learning:** This repository contains a newly drafted example implementation produced with AI assistance. If you adapt it as a personal portfolio project, read and test the code, make meaningful changes you understand, and describe your own work accurately rather than presenting AI-authored features as work you coded independently.

## Repository files

```text
health-records-portfolio/
├── app.py                     # Application, data layer and routes
├── assets/styles.css          # Layout and visual design
├── tests/test_app.py          # 12 automated tests
├── screenshots/               # Actual UI demonstration images
├── capture_screenshots.py     # Optional screenshot reproduction
├── README.md                  # You're reading it
├── TEST_RESULTS.md            # Test notes
├── requirements.txt           # No runtime third-party dependencies
├── .gitignore                 # Excludes local databases
└── LICENSE                    # MIT
```


## Development and attribution

This educational demonstration was created with AI assistance and should be reviewed, tested and modified by anyone using it as learning or portfolio work. Document your own contributions accurately; do not present generated code as independently authored.
